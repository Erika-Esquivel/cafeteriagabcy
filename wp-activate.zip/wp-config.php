<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'gabcy_cafe_bd' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '^ $$D@J$O;<<M-3eX/hw_<v^&B95U`b# 0$LU6L=oz2.U]aCz>p4P?1Ogx+cPCu]' );
define( 'SECURE_AUTH_KEY',  'YD{TOs1f=}Dl}<E;O22~;9uNO+vZZleflL.Q7TA(=|D,M{UUyv=a+s^V.8$GPrGk' );
define( 'LOGGED_IN_KEY',    'SY1p+KV|7iUNY%kaBT5:72fjP%SBv-2C{Qy:!+8$bn!U]Z{wt9st,`{(EdsV|v/&' );
define( 'NONCE_KEY',        'cN5VyAwlQXpC,S6Z{^M^qi.jmOI?E ?s7.=dC!zzDcj<aY>LQ(5cV01U_6)g+@im' );
define( 'AUTH_SALT',        '+`r<GLt7:f+Uxy=g4KHJy3j|~TM/5.vik}h>V_eJr#S<x/``0.#Q}1Klzt!6D=H!' );
define( 'SECURE_AUTH_SALT', '`cz@4Mv@C@{UFtC]}e$4Y=X%EH(|iVg fa)J[^K3v=+39)rD=[b+}[rAGeukE<_f' );
define( 'LOGGED_IN_SALT',   '!y2=)9Y=JZqBe@W.7<4w*sSl([<7&7VY%s&liKF{m<o#f=G~ciJ~~5nd.FAxWjjQ' );
define( 'NONCE_SALT',       'D[mql:)4Qw{ihh>A ww~D.Vib^U-NI4chGMT.%)-zfmB<dicS<nW/}=j,z>#~SVi' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
